#pragma once

#include <vector>
#include <string>
#include "Player.h"

class Game {
public:
    void loadRules(const std::string& filename);
    void setupPlayers();
    void play();

private:
    std::vector<Player> players;
    std::vector<std::string> rules;
    int currentPlayerIndex = 0;

    void printRules();
    void displayStatus();
    bool isGameOver();
};
