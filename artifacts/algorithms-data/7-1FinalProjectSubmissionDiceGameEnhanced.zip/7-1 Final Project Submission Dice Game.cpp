#include <iostream>
#include <string>
#include "Game.h"

int main() {
    std::cout << "Welcome to the LCR Dice Game!\n";
    std::cout << "This game simulates the classic LCR (Left Center Right) dice game.\n";
    std::cout << "Players take turns rolling dice and passing chips based on the roll.\n\n";

    try {
        Game game;
        game.loadRules("lcr_rules.txt");
        game.setupPlayers();
        game.play();
    }
    catch (const std::exception& e) {
        std::cerr << "An error occurred: " << e.what() << std::endl;
        return 1;
    }

    std::cout << "\nThanks for playing!\n";
    return 0;
}
