#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <vector>

class Player {
public:
    Player(std::string name);

    std::string getName() const;
    int getChips() const;
    bool isOut() const;
    void changeChips(int delta);

    // Handles a full turn (rolls dice and acts on results)
    void takeTurn(std::vector<Player>& players);

private:
    std::string name;
    int chips;

    // Returns a random die result: L, R, C, or .
    char rollDie();

    // Finds this player's index in the players list
    size_t findSelfIndex(const std::vector<Player>& players) const;
};

#endif
