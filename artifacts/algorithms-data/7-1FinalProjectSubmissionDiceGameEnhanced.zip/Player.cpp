#include "Player.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

Player::Player(std::string n) : name(n), chips(3) {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

std::string Player::getName() const {
    return name;
}

int Player::getChips() const {
    return chips;
}

bool Player::isOut() const {
    return chips <= 0;
}

void Player::changeChips(int delta) {
    chips += delta;
}

void Player::takeTurn(std::vector<Player>& players) {
    int rolls = std::min(chips, 3);
    if (rolls == 0) {
        std::cout << name << " has no chips and is skipped.\n";
        return;
    }

    size_t myIndex = findSelfIndex(players);

    for (int i = 0; i < rolls; ++i) {
        char result = rollDie();
        std::cout << name << " rolled " << result << "\n";

        if (result == 'L') {
            size_t left = (myIndex == 0) ? players.size() - 1 : myIndex - 1;
            players[left].changeChips(1);
            changeChips(-1);
        }
        else if (result == 'R') {
            size_t right = (myIndex + 1) % players.size();
            players[right].changeChips(1);
            changeChips(-1);
        }
        else if (result == 'C') {
            changeChips(-1); // Center: remove chip from game
        }
    }
}

char Player::rollDie() {
    int roll = std::rand() % 6;
    return "LRCLCR"[roll];
}

size_t Player::findSelfIndex(const std::vector<Player>& players) const {
    for (size_t i = 0; i < players.size(); ++i) {
        if (players[i].getName() == name) {
            return i;
        }
    }
    return 0; // fallback, shouldn't happen
}
