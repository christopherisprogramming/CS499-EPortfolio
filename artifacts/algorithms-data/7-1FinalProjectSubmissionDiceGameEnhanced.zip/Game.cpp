#include "Game.h"
#include <iostream>
#include <fstream>
#include <queue>

void Game::loadRules(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;
    rules.clear();
    while (std::getline(file, line)) {
        rules.push_back(line);
    }
}

void Game::setupPlayers() {
    int numPlayers;
    std::cout << "Enter number of players (minimum 3): ";
    std::cin >> numPlayers;

    if (numPlayers < 3) {
        std::cerr << "Error: Need at least 3 players.\n";
        exit(1);
    }

    players.clear();
    for (int i = 0; i < numPlayers; ++i) {
        players.emplace_back("Player " + std::to_string(i + 1));
    }
}

void Game::printRules() {
    std::cout << "\nGame Rules:\n";
    for (const auto& line : rules) {
        std::cout << line << '\n';
    }
    std::cout << std::endl;
}

void Game::displayStatus() {
    std::cout << "\nCurrent Game State:\n";
    for (const auto& p : players) {
        std::cout << p.getName() << " has " << p.getChips() << " chips.\n";
    }
}

bool Game::isGameOver() {
    int active = 0;
    for (const auto& p : players) {
        if (!p.isOut()) active++;
    }
    return active <= 1;
}

void Game::play() {
    printRules();

    std::queue<Player*> turnQueue;
    for (auto& p : players) {
        turnQueue.push(&p);
    }

    while (!isGameOver()) {
        Player* current = turnQueue.front();
        turnQueue.pop();

        if (!current->isOut()) {
            current->takeTurn(players);
            displayStatus();
        }

        turnQueue.push(current);
    }

    for (const auto& p : players) {
        if (!p.isOut()) {
            std::cout << "\nWinner is " << p.getName() << "!\n";
            break;
        }
    }
}
