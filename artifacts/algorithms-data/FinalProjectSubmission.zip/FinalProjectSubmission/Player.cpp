#include "Player.h"

Player::Player(const std::string& name)
{
    m_name = name;
    m_chips = 3;
}

void Player::SetName(const std::string& name)
{
    m_name = name;
}

const std::string& Player::GetName() const
{
    return m_name;
}

void Player::AddChip()
{
    m_chips++;
}

void Player::RemoveChip()
{
    if (m_chips > 0)
        m_chips--;
}

int Player::GetChips() const
{
    return m_chips;
}

bool Player::HasChips() const
{
    return m_chips > 0;
}
