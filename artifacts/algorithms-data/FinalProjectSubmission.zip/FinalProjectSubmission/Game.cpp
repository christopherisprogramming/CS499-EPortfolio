#include "Game.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

Game::Game() {
    m_centerChips = 0;
    std::srand(static_cast<unsigned int>(std::time(0)));
}

void Game::LoadRulesFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: Could not open rules file.\n";
        return;
    }

    std::string line;
    std::cout << "\nLCR Game Rules:\n\n";
    while (std::getline(file, line)) {
        std::cout << line << '\n';
    }
    std::cout << '\n';
    file.close();
}

void Game::SetupPlayers(int numPlayers) {
    for (int i = 0; i < numPlayers; ++i) {
        m_players.emplace_back("Player " + std::to_string(i + 1));
    }
}

void Game::Play() {
    while (!IsGameOver()) {
        for (size_t i = 0; i < m_players.size(); ++i) {
            Player& current = m_players[i];
            if (!current.HasChips()) continue;

            std::string input;
            do {
                std::cout << current.GetName() << "'s turn. Press 'r' and Enter to roll: ";
                std::getline(std::cin >> std::ws, input);
            } while (input != "r");

            int rollCount = std::min(3, current.GetChips());
            std::cout << current.GetName() << " rolls: ";

            for (int j = 0; j < rollCount; ++j) {
                int roll = rand() % 6 + 1;
                switch (roll) {
                case 1:
                    std::cout << "L ";
                    current.RemoveChip();
                    m_players[(i + m_players.size() - 1) % m_players.size()].AddChip();
                    break;
                case 2:
                    std::cout << "R ";
                    current.RemoveChip();
                    m_players[(i + 1) % m_players.size()].AddChip();
                    break;
                case 3:
                    std::cout << "C ";
                    current.RemoveChip();
                    ++m_centerChips;
                    break;
                default:
                    std::cout << "* ";
                    break;
                }
            }
            std::cout << "\n";
        }
    }
}

bool Game::IsGameOver() const {
    int playersWithChips = 0;
    for (const auto& player : m_players) {
        if (player.HasChips()) {
            playersWithChips++;
        }
    }
    return playersWithChips == 1;
}

void Game::DisplayWinner() const {
    for (const auto& player : m_players) {
        if (player.HasChips()) {
            std::cout << "\n" << player.GetName() << " wins the game!\n";
            break;
        }
    }
}
