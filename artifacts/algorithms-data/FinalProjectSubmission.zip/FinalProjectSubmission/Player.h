#pragma once
#include <string>

class Player
{
private:
    std::string m_name;
    int m_chips;

public:
    Player(const std::string& name);

    void SetName(const std::string& name);
    const std::string& GetName() const;

    void AddChip();
    void RemoveChip();
    int GetChips() const;
    bool HasChips() const;
};
