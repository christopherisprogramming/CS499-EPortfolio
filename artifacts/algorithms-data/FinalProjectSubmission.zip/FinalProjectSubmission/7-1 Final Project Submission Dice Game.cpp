/*

Christopher Gaunt
IT312
4/20/2025
7-1 Final Project Submission: Dice Game

*/

#include <iostream>
#include "Game.h"

int main() {
    Game game;

    game.LoadRulesFromFile("lcr_rules.txt");

    int numPlayers = 0;
    do {
        std::cout << "Enter number of players (minimum 3): ";
        std::cin >> numPlayers;
    } while (numPlayers < 3);

    game.SetupPlayers(numPlayers);
    game.Play();
    game.DisplayWinner();

    return 0;
}
