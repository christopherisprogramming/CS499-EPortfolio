#pragma once
#include <vector>
#include <string>
#include "Player.h"

class Game {
private:
    std::vector<Player> m_players;
    int m_centerChips;

public:
    Game();
    void LoadRulesFromFile(const std::string& filename);
    void SetupPlayers(int numPlayers);
    void Play();
    bool IsGameOver() const;
    void DisplayWinner() const;
};
