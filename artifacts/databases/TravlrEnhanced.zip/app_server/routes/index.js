const express = require('express');
const router = express.Router();

// API route handler modules
const tripsRoutes = require('../routes/trips'); // If trips.js exists
// Add more APIs here in future (e.g., users, bookings)

// Mount the API routes under /trips
router.use('/trips', tripsRoutes);

// Base route for health check or welcome
router.get('/', (req, res) => {
    res.status(200).json({ message: 'Welcome to the Travlr API' });
});

// Fallback for undefined routes
router.use((req, res) => {
    res.status(404).json({ message: 'Endpoint not found' });
});

module.exports = router;
