const mongoose = require('mongoose');

// Define the trip schema with stronger validation
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        unique: true,
        index: true,
        match: /^[A-Z0-9_-]+$/,
        trim: true
    },
    name: {
        type: String,
        required: true,
        index: true,
        trim: true
    },
    length: {
        type: Number,
        required: true,
        min: 1
    },
    start: {
        type: Date,
        required: true
    },
    resort: {
        type: String,
        required: true,
        trim: true
    },
    perPerson: {
        type: Number,
        required: true,
        min: 0
    },
    image: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        minlength: 10
    }
}, {
    timestamps: true // Automatically adds createdAt and updatedAt
});

// Create and export the model
const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
