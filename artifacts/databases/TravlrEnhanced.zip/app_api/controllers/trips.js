const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Mongoose model
const Model = mongoose.model('trips');

// Reusable helper to send consistent error responses
const sendError = (res, statusCode, message, logError = null) => {
    if (logError) console.error(message, logError);
    return res.status(statusCode).json({ success: false, message });
};

/**
 * GET: /trips
 * Description: Retrieve and return all trips from the database
 */
const tripsList = async (req, res) => {
    try {
        const trips = await Model.find({}).exec();

        if (!trips || trips.length === 0) {
            return sendError(res, 404, "No trips found");
        }

        return res.status(200).json({ success: true, count: trips.length, data: trips });
    } catch (error) {
        return sendError(res, 500, "Server error retrieving trips", error);
    }
};

/**
 * GET: /trips/:tripCode
 * Description: Retrieve a trip by its unique trip code
 */
const tripsFindByCode = async (req, res) => {
    const { tripCode } = req.params;

    // Validate tripCode: required and alphanumeric
    if (!tripCode || !/^[a-zA-Z0-9_-]+$/.test(tripCode)) {
        return sendError(res, 400, "Invalid or missing trip code format");
    }

    try {
        const trip = await Model.findOne({ code: tripCode }).exec();

        if (!trip) {
            return sendError(res, 404, `Trip with code '${tripCode}' not found`);
        }

        return res.status(200).json({ success: true, data: trip });
    } catch (error) {
        return sendError(res, 500, `Server error retrieving trip with code '${tripCode}'`, error);
    }
};

// Export API methods
module.exports = {
    tripsList,
    tripsFindByCode
};
