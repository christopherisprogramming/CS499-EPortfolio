const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travel'); // Correct path to the controller

// Define route for the travel endpoint
router
    .route('/')
    .get(travelController.travel); // Make sure the controller method is correct

module.exports = router;
