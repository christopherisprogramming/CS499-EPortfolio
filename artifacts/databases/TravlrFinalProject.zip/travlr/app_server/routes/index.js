var express = require('express');
var router = express.Router();
var mainController = require('../controllers/main'); // Reference main controller

/* GET home page. */
router.get('/', mainController.index); // Use controller instead of inline function

module.exports = router;
