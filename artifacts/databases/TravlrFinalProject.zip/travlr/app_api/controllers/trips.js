const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');

// GET: /trips - Lists all the trips
// Returns all trips from the database
const tripsList = async (req, res) => {
    try {
        const q = await Model.find({}).exec(); // Retrieve all trips

        if (!q || q.length === 0) {
            return res.status(404).json({ message: "No trips found" });
        }

        return res.status(200).json(q);
    } catch (err) {
        return res.status(500).json({ message: "Error retrieving trips", error: err });
    }
};

// GET: /trips/:tripCode - Retrieves a single trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const q = await Model.findOne({ code: req.params.tripCode }).exec(); // Retrieve trip by code

        if (!q) {
            return res.status(404).json({ message: "Trip not found" });
        }

        return res.status(200).json(q);
    } catch (err) {
        return res.status(500).json({ message: "Error retrieving trip", error: err });
    }
};

// Export the functions for use in routes
module.exports = {
    tripsList,
    tripsFindByCode
};
