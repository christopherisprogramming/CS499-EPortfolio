const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Load the Trip model
const Trip = require('./travlr');

// MongoDB connection URL
const dbURI = 'mongodb://127.0.0.1/travlr';

// Connect to MongoDB
mongoose.connect(dbURI);

mongoose.connection.on('connected', async () => {
    console.log(`Connected to MongoDB at ${dbURI}`);

    try {
        // Read trips.json file
        const tripsDataPath = path.join(__dirname, '../../data/trips.json');
        const trips = JSON.parse(fs.readFileSync(tripsDataPath, 'utf8'));

        // Clear existing trips collection
        await Trip.deleteMany({});
        console.log('Existing trips collection cleared.');

        // Insert new trips
        await Trip.insertMany(trips);
        console.log('Trips successfully seeded into MongoDB.');
    } catch (error) {
        console.error('Error seeding database:', error);
    } finally {
        await mongoose.connection.close();
        console.log('Disconnected from MongoDB.');
        process.exit(0);
    }
});

mongoose.connection.on('error', (err) => {
    console.error('MongoDB connection error:', err);
});
