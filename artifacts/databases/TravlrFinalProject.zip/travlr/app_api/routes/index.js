const express = require('express'); // Express app
const router = express.Router();    // Router logic

// Import the controllers we will route
const tripsController = require('../controllers/trips');

// Define route for retrieving all trips
router
    .route('/trips')
    .get(tripsController.tripsList); // GET Method routes tripsList

// Define route for retrieving a single trip by code (Parameterized Route)
router
    .route('/trips/:tripCode') // Route takes a tripCode parameter
    .get(tripsController.tripsFindByCode); // GET Method routes tripsFindByCode

module.exports = router;
